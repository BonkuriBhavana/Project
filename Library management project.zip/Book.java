
public class Book {
     String bookId;
     String title;
     String author;
     boolean available;
	static Book obj = new Book();
  // Constructor
    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.available = true;
    }

    // Getters
    public String getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public boolean getAvailable(){
        return available;
    }
    public  void setAvailable(boolean b){
        available=b;
    }
    public String getAuthor() {
        return author;
    }

    // Display book information
    public void displayBookInfo() {
        System.out.println(Designs.CYAN+"Book ID: " + bookId);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Available: " + (available ? "Yes" : "No") + Designs.RESET);
    }
    public Book(){}
}