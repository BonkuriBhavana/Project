
public class Designs{
public static final String RESET = "\033[0m";  // Text Reset

    // Colors
    public static final String RED = "\033[31m";
    public static final String GREEN = "\033[32m";
    public static final String YELLOW = "\033[33m";
    public static final String BLUE = "\033[34m";
    public static final String PURPLE = "\033[35m";
    public static final String CYAN = "\033[36m";
    static final String black = "\u001B[30m";
    public static final String WHITE = "\033[37m";

    //color reset
    public static final String reset = "\u001B[0m";

    //bright colors
   public static final String redbr = "\033[0;91m";
    public static final String greenbr = "\033[0;92m";
    public static final String whitebr = "\033[0;97m";

    //bright high intensity
   public static final String redbri = "\033[1;91m";   // RED
    public static final String greenbri = "\033[1;92m";
    public static final String bluebri = "\033[0;94m";

    //Background colors
   public static final String bwhite = "\u001B[107m";
   public static String bgreen="\u001B[42m";
    public static String byellow="\u001B[43m";
   public static String bblue="\u001B[44m";
    public static String bpurple="\u001B[45m";
    public static String bcyan="\u001B[46m";
    public static String change="\u001B[7m";
   public static String thick="\u001B[1m";


    //background color reset
   public static String breset = "\u001B[49m";

    //underline
   public static final String ul = "\u001B[4m";

    //underline reset
    public static final String rstul = "\u001B[24m";

    //blinking
   public static final String blink="\u001B[5m";

    //reset blinking
    public static final String rstblink = "\u001B[0m";

    //italic
    public static final String ital = "\u001B[3m";


   public static String bold="\u001B[1m";
   public static String whitebg="\u001B[47m";
   public static String back ="\u001B[30m";

}