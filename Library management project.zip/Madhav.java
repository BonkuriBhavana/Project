import java.util.Scanner; 
import java.time.LocalDate; 
import java.time.format.DateTimeFormatter; 
import java.time.temporal.ChronoUnit;

public class Madhav {
    static Scanner sc = new Scanner(System.in);
    static String bDate;
    static Book bb = new Book();
    static String after5Days;
	
    static void  borrow( BookService bs){
        try{  
            System.out.println("Enter the number of books to borrow :");
            int n=sc.nextInt();
            if(n<=BookService.books.size()){

                for(int i=1;i<=n;i++){  

                    System.out.println("Enter the book Id you want to Borrow :");
                    String id =sc.next();
                    
                    for (Book b : bs.books) {  
                        if (b.getBookId().equals(id)) {  
                       
                            if (b.getAvailable()==true) {
                                
                                b.setAvailable(false);
                                System.out.println("You have successfully borrowed the book: " + b.getBookId());
                                System.out.println("Book ID: " +b. bookId);
                                System.out.println("Title: " + b.title);
                                System.out.println("Author: " +b. author);
                                System.out.println();
                                sc.nextLine();
                            } else {
                                System.out.println("The book is not available for borrowing. Plz select Another one :");
                                i--;
                                continue;
                                
                            }
                            break; 
                        }
                    }
                }
            
            
                bDate = getValidDate();

                after5Days=after5(bDate);
            }else{
                System.out.println("Library has not that much of Books Plz Select Number : <= "+BookService.books.size());
                sc.nextLine();
                System.out.println();
                borrow(bs);
            }
        }
        catch(Exception e){
            System.out.println("Plz Read the statements and enter the proper Inputs :");
            sc.nextLine();
            System.out.println();
            borrow(bs);
        }


    }

    static void returnBook(BookService bs){

        try{
            if(bDate==null){
                System.out.println("You didn't borrow any Books :");
                return;
            }
            System.out.println("Enter the number of books to Return :");
            int n=sc.nextInt();

            for(int i=1;i<=n;i++){  

                System.out.println("Enter the book Id you want to Return :");
                String id =sc.next();
                
                for (Book b : bs.books) {  
                    if (b.getBookId().equals(id)) {  
                            b.setAvailable(true );
                            System.out.println("You have successfully Returned the book: " + b.getBookId());
                            System.out.println();
                            sc.nextLine();
                            break; 
                    }
                }
            }


            rDate(bDate);
        }
        catch(Exception e){
            System.out.println("Plz Read the statements and enter the proper Inputs :");
            sc.nextLine();
            System.out.println();
            returnBook(bs);
        }


        bDate=null;
    }

    static int daysBetween;
    static String rDate;
    static String rDate( String bdatepara){

        boolean b = true;
        
        while (b) {
            System.out.println("Please Enter the Return date: (format: dd-MM-yyyy): ");
            String inputDate = sc.nextLine();

            // Define a DateTimeFormatter to parse the date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            
            try {
                
                LocalDate userDate = LocalDate.parse(inputDate, formatter);
                
                LocalDate borDate = LocalDate.parse(bdatepara, formatter);
                
                if ((userDate.isBefore(borDate))) {
                    System.out.println("You cannot enter a past date. Please enter that day's  date or a future date.");
                    continue;
                } else {
                    
                    rDate=userDate.format(formatter);
                    daysBetween=0;
                    daysBetween = (int)ChronoUnit.DAYS.between(borDate, userDate);
                        daysBetween+=1;
                     
                }
                if(daysBetween<=6){
                    System.out.println("Thank you for returning the book on time !");
                    return userDate.format(formatter);
                }else{
                    daysBetween=daysBetween-6;
                    System.out.println("Borrowing Date :"+bdatepara);
                    System.out.println("Due Date :"+after5Days);
                    System.out.println("Return Date :"+userDate.format(formatter));
                    System.out.println("Overdue Days :"+daysBetween+" days");
                    int fee=(int)daysBetween*2;
                    System.out.println("Late fee charged :$"+fee);
                    return userDate.format(formatter);
                }

            } catch (Exception e) {
                System.out.println("Invalid date format! Please enter the date in dd-MM-yyyy format.");
                continue;
            }
        }

        return "";
    }



    static void callFine() {

        System.out.println("Sample Fine Calculator ------>");
        System.out.println("Enter the Borrowing Date :");
        String start=getValidDate();
        System.out.println("Return Due Date :"+after5(start));
        System.out.println("Please return the book on or before the due to avoid late fees.");
        System.out.println();
        
        rDate(start);

        //System.out.println(after5Days);
        
    }


    static void feedback() {
        try {
            System.out.println("Enter the Book Id:");
            String id = sc.next(); 
    
            boolean bookFound = false;
    
            for (Book b : BookService.books) {
                if (b.getBookId().equals(id)) {
                    bookFound = true; 
                    sc.nextLine(); 
                    System.out.println("Write your feedback:");
                    String fdb = sc.nextLine().trim(); 
                    System.out.println("Thank you for your feedback: About Book ID : "+id+" : "+ fdb);
                    break; 
                }
            }
            if (!bookFound) {
                System.out.println("Book Id Not Valid. Please try again.");
                feedback(); 
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            sc.nextLine(); 
            feedback(); 
        }
    }
    
    

   static public String after5(String bDate){

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        
        LocalDate date = LocalDate.parse(bDate, formatter);

        LocalDate newDate = date.plusDays(5);
        System.out.println("Plz Return the Books within 6 days of borrowing that is ->: "+newDate.format(formatter));
        System.out.println("Note : A late fee of  $2 per day will be charged for overdue returns. ");
        System.out.println();
        after5Days=newDate.format(formatter);
        return newDate.format(formatter);

    }
    static String getValidDate() {
        boolean b = true;
        
        while (b) {
            System.out.println("Enter the date of Borrowing : (format: dd-MM-yyyy): ");
            String inputDate = sc.nextLine();

            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

            try {
                
                LocalDate userDate = LocalDate.parse(inputDate, formatter);
                LocalDate currentDate = LocalDate.now(); 

                
                if (userDate.isBefore(currentDate)) {
                    System.out.println("You cannot enter a past date. Please enter today date or a future date.");
                    continue;
                } else {
                    return userDate.format(formatter); 
                }
            } catch (Exception e) {
                System.out.println("Invalid date format! Please enter the date in dd-MM-yyyy format.");
                continue;
            }
        }
        return "";
    }

    public static void main(String[] args) {
        
        String validDate = getValidDate(); 
        System.out.println("You entered the valid date: " + validDate); 
    }
}
