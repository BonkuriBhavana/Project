

import java.util.ArrayList;

public class UserService {
    private ArrayList<User> users;

    public UserService() {
        users = new ArrayList<>();
    }

    // Register a new user
    public boolean registerUser(String userId, String name, String email, String password) {
        for (User user : users) {
            if (user.getUserId().equals(userId)) {
                System.out.println(Designs.greenbr+"User ID already exists. Registration failed."+Designs.RESET);
                return false;
            }
        }
        users.add(new User(userId, name, email, password));
        System.out.println(Designs.blink+"User registered successfully!"+Designs.rstblink);
        return true;
    }

    // List all registered users
    public void listUsers() {
        if (users.isEmpty()) {
            System.out.println(Designs.RED+"No registered users found."+Designs.RESET);
        } else {
            for (User user : users) {
                user.displayUserInfo();
                System.out.println("------------------------");
            }
        }
    }
}