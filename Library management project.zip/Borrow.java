
import java.util.ArrayList;
import java.util.List;

public class Borrow {
    private List<Book> books;

    public Borrow() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public Book findBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // If the book is not found
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }
}
