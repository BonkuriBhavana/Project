

import java.util.ArrayList;
import java.util.Iterator;

public class BookService {
    static ArrayList<Book> books;

    public BookService() {
        books = new ArrayList<>();
    }

    // Add a new book
    public static void addBook(String bookId, String title, String author) {
        // Check if the book ID already exists
        for (Book book : books) {
            if (book.getBookId().equals(bookId)) {
                System.out.println(Designs.redbr+"Book ID already exists. Cannot add the book."+Designs.RESET);
                return;
            }
        }
        books.add(new Book(bookId, title, author));
            }

    // Remove a book by ID
    public void removeBook(String bookId) {
        Iterator<Book> iterator = books.iterator(); // Use iterator to safely remove elements
        while (iterator.hasNext()) {
            Book book = iterator.next();
            if (book.getBookId().equals(bookId)) {
                iterator.remove();  // Remove safely using iterator
                System.out.println(Designs.BLUE+"Book removed successfully!"+Designs.RESET);
                return;
            }
        }
        System.out.println(Designs.PURPLE+"Book not found. Cannot remove."+Designs.RESET);
    }

    // List all books
    public void listBooks(){
        if (books.isEmpty()) {
            System.out.println(Designs.RED+"No books available in the library."+Designs.RESET);
        } else {
            for (Book book : books) {
                book.displayBookInfo(); // Assuming this method displays book details
                System.out.println(Designs.YELLOW+"------------------------"+Designs.RESET);
            }
        }
    }
}