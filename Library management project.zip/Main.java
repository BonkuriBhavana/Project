import java.util.Scanner;

public class Main {
    static UserService userService = new UserService();
    static BookService bookService = new BookService();
    static Scanner sc = new Scanner(System.in);
	static String[] args = {"Hello", "World"};
    // This method will add books to the BookService's book list
    static{
        bookService.addBook("1", "Java Book", "Author Krishna");
        bookService.addBook("2", "Programming", "Author Phani Kumar");
        bookService.addBook("3", "CyberSecurity", "Author Renuka Prasad");
        bookService.addBook("4", "Data Science", "Author Prem");
        bookService.addBook("5", "DBMS", "Author Manikanta");
        bookService.addBook("6", "C", "Author Sadashivani");
        bookService.addBook("7", "Python", "Author Sumathi");
        bookService.addBook("8", "Web Technology", "Author Ramya");
        bookService.addBook("9", "Cloud computing", "Author Srujana");
        bookService.addBook("10", "PHP", "Author Vamshi");
    }


	static void main1(){

		// Initialize books
        //existedBooks();  // Add sample books to the bookService
		System.out.println(Designs.bblue + " Welcome To Library Management System " + Designs.breset);
        while (true) {

           
            System.out.println(Designs.RED+"1. Register New User");
            System.out.println("2. List Registered Users");
            System.out.println("3. Add New Book");
            System.out.println("4. Remove Book");
            System.out.println("5. List Books");
            System.out.println("6. Borow Books");
            System.out.println("7. Return Books");
            System.out.println("8. Sample Fine Calculator");
            System.out.println("9. Feedback");
            System.out.println("10. Exit"+Designs.RESET);
            System.out.print(Designs.greenbr+"Enter your choice: "+Designs.RESET);

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Register a new user
                    System.out.print(Designs.PURPLE+"Enter User ID: "+Designs.RESET);
                    String userId = sc.nextLine();
                    System.out.print(Designs.YELLOW+"Enter Name: "+Designs.RESET);
                    String name = sc.nextLine();
                    System.out.print(Designs.CYAN+"Enter Email: "+Designs.RESET);
                    String email = sc.nextLine();
                    System.out.print(Designs.GREEN+"Enter Password: "+Designs.RESET);
                    String password = sc.nextLine();
                    userService.registerUser(userId, name, email, password);
                    break;

                case 2:
                    // List all registered users
                    userService.listUsers();
                    break;

                case 3:
                    // Add a new book
                    System.out.print(Designs.CYAN+"Enter Book ID: ");
                    String bookId = sc.nextLine();
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Author: "+Designs.RESET);
                    String author = sc.nextLine();
                    bookService.addBook(bookId, title, author);
                    break;

                case 4:
                    // Remove a book by ID
                    System.out.print(Designs.BLUE+"Enter Book ID to remove: "+Designs.RESET);
                    String removeBookId = sc.nextLine();
                    bookService.removeBook(removeBookId);
                    break;

                case 5:
                    // List all books
                    bookService.listBooks();
                    break;
				case 6:
                    Madhav.borrow(bookService);
                    break;
                case 7:
                    Madhav.returnBook(bookService);
                    break;
                case 8:
                    Madhav.callFine();
                    break;
                case 9:
                    Madhav.feedback();
                    break;

                case 10:
                    // Exit the program
                    System.out.println(Designs.blink+"Exiting system. Thank you visit again!!"+Designs.rstblink);
                    sc.close();
					System.exit(0);

                default:
                    // Invalid choice
                    System.out.println(Designs.RED+"Invalid choice. Please try again."+Designs.RESET);
			}
		}
	}
	public static void admin(){
		try{
			System.out.println("Enter the admin Password : ");
			int pin=sc.nextInt();
			if(pin==apin){
				System.out.println("Admin Login Successful: ");
			
				while(true){
					
					try{
						System.out.println("1. List of Registered Users :");
						System.out.println("2. Add New Book :");
						System.out.println("3. Remove Book :");
						System.out.println("4. List Books :");
						System.out.println("5. Home Page : ");
						System.out.println("6. Exit : ");
						System.out.print("Select the Option : ");
						int val = sc.nextInt();
						switch(val){
							case 1:	
								userService.listUsers();
								break;
							case 2:
								sc.nextLine();
								System.out.print(Designs.CYAN+"Enter Book ID: ");
								String bookId = sc.nextLine();
								System.out.print("Enter Title: ");
								String title = sc.nextLine();
								System.out.print("Enter Author: "+Designs.RESET);
								String author = sc.nextLine();
								bookService.addBook(bookId, title, author);
								break;
							case 3:
								System.out.print(Designs.BLUE+"Enter Book ID to remove: "+Designs.RESET);
								sc.nextLine();
								String removeBookId = sc.nextLine();
								bookService.removeBook(removeBookId);
								break;
							case 4:
								bookService.listBooks();
								break;
							case 5:
								return;
							case 6:
								System.out.println(Designs.blink+"Exiting system. Thank you visit again!!"+Designs.rstblink);
								sc.close();
								System.exit(0);
								break;
							default: System.out.println("Enter the valid Option (1-6) :");
								continue;
						}
						
					}
					catch(Exception e){
						sc.nextLine();
						System.out.println("Enter a Number :");
						continue;
						
					}
							
						
					
					
					
					
				}
			}
			else{
				System.out.println(" Invalid Password: ");
				System.out.println("Try Again :");
				admin();
			}
		}
		catch(Exception e){
			sc.nextLine();
			System.out.println("Enter the Valid Pin: ");
			admin();
			
		}
		
		
	}
	static int apin=12345;
	
	static Authentication au=new Authentication();
	static User u;
	
	public static void userMenu(){
		
		while(true){
			//System.out.println(" USer Services ");
			System.out.println("1. List of Book :");
			System.out.println("2. Borrow a Books :");
			System.out.println("3. Return a Book :");
			System.out.println("4. Sample Fine Calculator :");
			System.out.println("5. Feedback :");
			System.out.println("6. Exit :");
			System.out.println("7. Home Page:");
			System.out.println("Select the Option :");
			
			try{
				int n = sc.nextInt();
				switch(n){
					case 1:  	bookService.listBooks();
								break;
					case 2: 	Madhav.borrow(bookService);
								break;
					case 3:	 	Madhav.returnBook(bookService);
								break;	
					case 4: 	Madhav.callFine();
								break;
					case 5:		Madhav.feedback();
								break;
					case 6: 	System.exit(0);
								break;
					case 7: 	main(args);
					
					default :	 System.out.println("Enter the valid Option(1-6) :");
					continue;
					
				}
			}catch(Exception e){
				sc.nextLine();
				System.out.println("Enter the Number :");
				
			}
		}
		
		
		
	}
	
	
	
	
	public static void user(){
		
		
		while(true){
			System.out.println("1. Register :");
			System.out.println("2. Login :");
			//System.out.println("3. Back :");
			System.out.println("Select the Option :");
			try{
				int val=sc.nextInt();
				switch(val){
					case 1:   
								u= au.register();
								break;
								
					case 2:
								if(Authentication.register==true){
									au.login(u);
									
									if(Authentication.login==true){
										
										userMenu();
									}
									
								}
								else{
									System.out.println(" Plz Register First and then Login :");
								}
								break;
					// case 3:
								// return;
					
					default : System.out.println("Select the valid Option (1 or 2) ");
					continue;
				}
			}
			catch(Exception e){
				System.out.println("Enter the Valid Number :");
				sc.nextLine();
			}
				
				
				
			
		}
			
		
		
		
	}
	
	public static void main(String[] args){
		
		System.out.println(Designs.bblue + " Welcome To Library Management System " + Designs.breset);
	   
		while(true){
			System.out.println("1. Admin Login : ");
			System.out.println("2. User Login : ");
			try{
				System.out.print("Enter the Option : ");
				int val= sc.nextInt();
				switch(val){
					case 1:   
						admin();	
						break;
					case 2 :
						user();
						
					break;
					default : System.out.println("Enter the Valid Option (1 or 2) : ");
				}
			}
			catch(Exception e){
				System.out.println(" Enter the Valid Number :");
				sc.nextLine();
				continue;
			}
			
		}
		
		
	}
}
 
