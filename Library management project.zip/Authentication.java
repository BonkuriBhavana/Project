

import java.util.Scanner;
import java.util.regex.Pattern;
public class Authentication {
	static boolean login=false;
	static boolean register=false;
	
	
	static Scanner scanner = new Scanner(System.in);
	public static User register() {
        

        System.out.println("Enter your name:");
        String name = scanner.nextLine();
		String email;
		while(true){
			System.out.println("Enter your email:");
			email = scanner.nextLine();

			// Validate email
			if (!email.contains("@")) {
				System.out.println("Invalid email format. Email must contain '@'. \nTry Again :");
				
				continue;
			}
			break;
		}
		String password;
		while(true){
			System.out.println("Enter your password:");
			password = scanner.nextLine();

			// Validate password
			if (password.length() < 6 ||
				!Pattern.compile("[A-Z]").matcher(password).find() || // At least one uppercase
				!Pattern.compile("[a-z]").matcher(password).find() || // At least one lowercase
				!Pattern.compile("[0-9]").matcher(password).find()) { // At least one number
				System.out.println("Password must be at least 6 characters and contain at least one uppercase letter, one lowercase letter, and one number.");
				continue;
			}
			break;
		}

        System.out.println("Registration successful!Plz Login :");
		register=true;
        return  new User(name, email, password);
    }
	
	
	public static void login(User user) {
        
		while(true){
		
			System.out.println("Enter your email:");
			String inputEmail = scanner.nextLine();

			System.out.println("Enter your password:");
			String inputPassword = scanner.nextLine();

			
				// Validate login
				if (!user.getEmail().equals(inputEmail)) {
					System.out.println("Email does not match our records.");
					System.out.println("Login failed: ");
					login=false;
					continue;
					
				}
				
				if (!user.getPassword().equals(inputPassword)) {
					System.out.println("Password is incorrect.");
					System.out.println("Login failed: ");
					login=false;
					continue;
				}
				
				System.out.println("Login successful! Welcome, " + user.getName() + ".");
				login=true;
				return;
		}	
			
    }
	
	
	
	
	
}
