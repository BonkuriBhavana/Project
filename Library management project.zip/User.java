

public class User {
    //private String userId;
    private String name;
    private String email;
    private String password;

    // Constructor
    public User(String name, String email, String password) {
       // this.userId = userId;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
	
	public String getPassword() {
        return password;
    }

    // Display user information
   
   void displayUserInfo(){
	   System.out.println("Name : " + name);
       System.out.println("Email : " + email);
	   System.out.println("Password : " + password);
	   
	   
	}
	   
}